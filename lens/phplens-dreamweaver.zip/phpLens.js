

//---------------   GLOBAL VARIABLES   ---------------

var helpDoc = '';

//---------------     API FUNCTIONS    ---------------

function isDOMRequired() { 
	// Return false, indicating that this object is available in code view.
	return false;
}

function objectTag() {
  // Return the html tag that should be inserted
  var s='',id;

  id = document.forms[0].id.value;
  if (!id) id = 'ID not set';
 
  s += '<?php include_once("/path/to/phplens.inc.php"); session_start(); ?>\n';
  s += '<!-- put the above line at the top of the file and set the path to phplens dir... -->\n\n';
  s += '<?php\n';
  s += '//                      ID, Server Type, Server, UserID, Password, Database, SQL\n';
  s += '$lens = PhpLensPConnect("'+id+'" ,"'+ document.forms[0].servertype.value+'" ,"'+ document.forms[0].server.value+'" ,"'+ document.forms[0].userid.value+'" ,"'+ document.forms[0].password.value+'" ,"'+ document.forms[0].db.value+'" ,"'+ document.forms[0].sql.value+'");\n';
  s += '\n';
  s += '//----------------------------------------------------\n';
  s += '//Enable the following line to disable dynamic editing\n';
  s += '//$lens->dynEdit = 0;\n';
  s += '$lens->Render();\n';
  s += '$lens->Close();\n';
  s += '?>\n';

  return s;
}
